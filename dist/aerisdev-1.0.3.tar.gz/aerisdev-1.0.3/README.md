me and some friends made a joke when a database went down and said sql.dumpdb (dump as in throwing something in the dumpster)
DO NOT USE THIS 
